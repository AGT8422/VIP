<?php

namespace App\Http\Controllers\ApiController;

use App\Http\Controllers\Controller;
use App\Utils\BusinessUtil;
use DB;
use Illuminate\Validation\Rule;
use App\Utils\ModuleUtil;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Spatie\Activitylog\Models\Activity;
use Laravel\Sanctum\Contracts;
use Illuminate\Session\Store;
use Utils\Util;
use Illuminate\Support\Str;
use App\Models\User;
 
class ApiLoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * All Utils instance.
     *
     */
    protected $businessUtil;
    protected $moduleUtil;
    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    // protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(BusinessUtil $businessUtil, ModuleUtil $moduleUtil)
    {
        $this->middleware('guest')->except('logout');
        $this->businessUtil = $businessUtil;
        $this->moduleUtil = $moduleUtil;
    }

    public function login(Request $request)
    {
      
       $user = User::where("username",$request->username)->first();

       $credentials = $request->only('username', 'password');
        
        if(!$user || !Hash::check($request->password,$user->password)){
            return response([
                "status"  => "403",
                "message" => "Invalid",
                "result"  => 0
            ],404);
        }
        $credentialsnt        =  $request->only(["username","password"]);
        $token                =  Auth::guard('api')->attempt($credentialsnt);
        $user                 =  User::find($user->id);
     
        
              
        $user->api_token  = $token;
        $user->update();
        // $authToken = Str::random(40);
        // $token     = JWT::encode($User->toArray(), $authToken, 'HS256');
        return response()->json([
            'status'   => 'success',
             'authorisation' => [
                'token' => $token,
                'type'  => 'Bearer',
            ]
        ]);
 
    }
    public function logout(Request $request)
    {
         
        $this->guard()->logout();
         
       
        if ($response = $this->loggedOut($request)) {
            return $response;
        }

        return $request->wantsJson()
            ? new JsonResponse([], 204)
            : redirect('/');
    }

    /** ----------------------------------------------------------  **/
    /**                     Get Sell Bill                           **/
    /** ----------------------------------------------------------  **/
    public function getBill(Request $request)
    {

        $api_token = $request->token;
        $user      = User::where("api_token",$api_token)->first();
        
        if(!$user){
            abort(403, 'Unauthorized action.');
        }

        $user_id = $user->id;
        $sells   = \App\Transaction::join("transaction_payments as tp","transactions.id","tp.transaction_id")->whereIn("type",["sale","sell_return"])->select(["transactions.id","transactions.store_id","transactions.contact_id","transactions.agent_id","transactions.total_before_tax","transactions.final_total","transactions.transaction_date","transactions.transaction_date" ,"transactions.sell_lines","transactions.invoice_no","tp.created_by","transactions.payment_status","tp.amount"])->where("tp.created_by",$user->id)->get();
        
 
        return response()->json([
                "sales" => $sells   ,
                "token" => $last_api
            ]);
    }
    /** ----------------------------------------------------------  **/
    /**                     Get Sell Bill                           **/
    /** ----------------------------------------------------------  **/
    public function store(Request $request)
    {
        
        $api_token = request()->input("token");
        $api       = substr( $api_token,1);
        $last_api  = substr( $api_token,1,strlen($api)-1);
        $user      = User::where("api_token",$last_api)->first();
        
        if(!$user){
            abort(403, 'Unauthorized action.');
        }

        $user_id = $user->id;

        
        
        return response()->json([
                "sales" => $sells,
                "token" => $last_api
            ]);
    }
    protected function guard()
    {
        return Auth::guard();
    }
}
