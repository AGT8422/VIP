<?php

namespace App\Http\Controllers\ApiController;

use App\Http\Controllers\Controller;
use App\Utils\BusinessUtil;
use DB;
use Illuminate\Validation\Rule;
use App\Utils\ModuleUtil;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Transaction;
use App\Utils\TransactionUtil;
use App\Utils\CommonUtil;
use App\Utils\RestUtil;
use Spatie\Activitylog\Models\Activity;
use Laravel\Sanctum\Contracts;
use Illuminate\Session\Store;
use Utils\Util;
use Illuminate\Support\Str;
use App\Models\User;
 
class DashboardController extends Controller
{
 
    /**
     * All Utils instance.
     *
     */
    protected $businessUtil;
    protected $transactionUtil;
    protected $moduleUtil;
    protected $commonUtil;
    protected $restUtil;

    public function __construct(
        BusinessUtil $businessUtil,
        TransactionUtil $transactionUtil,
        ModuleUtil $moduleUtil
    ) {
        $this->businessUtil    = $businessUtil;
        $this->transactionUtil = $transactionUtil;
        $this->moduleUtil      = $moduleUtil;
    }

    //.............. DashBoard ...............\\
    // ************************************** \\
    public function Dashboard(Request $request){

        try{
            $api_token = request()->input("token");
            $api       = substr( $api_token,1);
            $last_api  = substr( $api_token,1,strlen($api)-1);
            $token     = $last_api;
            if($api_token == "" &&  $api_token == null){
                abort(403, 'Unauthorized action.');
            } 
            $user      = \App\User::where("api_token",$token)->first();
           
            if(!$user){
                abort(403, 'Unauthorized action.');
            } 
            // ************* Requirment ************* \\
            $reportSetting      =  \App\Models\ReportSetting::select("*")->first();
            //.......
            $dailystart         = \Carbon::now();
            $dailyend           = \Carbon::now();
            //.......
            $monthstart         = \Carbon::now()->subMonth(0)->day(0);
            $monthend           = \Carbon::now()->subMonth(0);
            //.......
            $yearstart          = \Carbon::now()->subYear(1);
            $yearend            = \Carbon::now()->subYear(0);
            //.......
            $business_id        = $user->business_id;
            $location_id        = \App\BusinessLocation::allLocation($business_id);
            $transaction_types = [
                'purchase_return', 'sell_return', 'expense'
            ];
            // ** End Requirment ********************* \\
            
            
            
            // *********** Daily   Sale            ************ \\
            // *********** Daily   Purchase        ************ \\
            // *********** Daily   Debit Sale      ************ \\
            // *********** Daily   Debit Purchase  ************ \\
            $dailysell_details       = $this->transactionUtil->getSellTotals($business_id, $dailystart, $dailyend, $location_id , $user->id,$reportSetting,1);
            $dailypurchase_details   = $this->transactionUtil->getPurchaseTotals($business_id, $dailystart, $dailyend, $location_id, $user->id,$reportSetting,1);
            $dailytransaction_totals = $this->transactionUtil->getTransactionTotals(
                $business_id,
                $transaction_types,
                $dailystart,
                $dailyend,
                $location_id,
                $user->id,
                $reportSetting,1
            );
           
            $dailytotal_purchase_inc_tax        = !empty($dailypurchase_details['total_purchase_inc_tax']) ? $dailypurchase_details['total_purchase_inc_tax'] : 0;
            $dailytotal_purchase_return_inc_tax = $dailytransaction_totals['total_purchase_return_inc_tax'];
            $dailytotal_purchase                = $dailytotal_purchase_inc_tax - $dailytotal_purchase_return_inc_tax;
            $dailyoutput                        = $dailypurchase_details;
            $dailyoutput['total_purchase']      = $dailytotal_purchase;
            $dailytotal_sell_inc_tax            = !empty($dailysell_details['total_sell_inc_tax']) ? $dailysell_details['total_sell_inc_tax'] : 0;
            $dailytotal_sell_return_inc_tax     = !empty($dailytransaction_totals['total_sell_return_inc_tax']) ? $dailytransaction_totals['total_sell_return_inc_tax'] : 0;
            $dailyoutput['total_sell']          = $dailytotal_sell_inc_tax - $dailytotal_sell_return_inc_tax;
            $dailyoutput['invoice_due']         = $dailysell_details['invoice_due'];

            // *********** Monthly Sale            ************ \\
            // *********** Monthly Purhcase        ************ \\
            // *********** Monthly Debit Sale      ************ \\
            // *********** Monthly Debit Purhcase  ************ \\
            $monthsell_details       = $this->transactionUtil->getSellTotals($business_id, $monthstart, $monthend, $location_id, $user->id,$reportSetting,1);
            $monthpurchase_details   = $this->transactionUtil->getPurchaseTotals($business_id, $monthstart, $monthend, $location_id, $user->id,$reportSetting,1);
            $monthtransaction_totals = $this->transactionUtil->getTransactionTotals(
                $business_id,
                $transaction_types,
                $monthstart,
                $monthend,
                $location_id, $user->id,$reportSetting,1
            );
           
            $monthtotal_purchase_inc_tax        = !empty($monthpurchase_details['total_purchase_inc_tax']) ? $monthpurchase_details['total_purchase_inc_tax'] : 0;
            $monthtotal_purchase_return_inc_tax = $monthtransaction_totals['total_purchase_return_inc_tax'];
            $monthtotal_purchase                = $monthtotal_purchase_inc_tax - $monthtotal_purchase_return_inc_tax;
            $monthoutput                        = $monthpurchase_details;
            $monthoutput['total_purchase']      = $monthtotal_purchase;
            $monthtotal_sell_inc_tax            = !empty($monthsell_details['total_sell_inc_tax']) ? $monthsell_details['total_sell_inc_tax'] : 0;
            $monthtotal_sell_return_inc_tax     = !empty($monthtransaction_totals['total_sell_return_inc_tax']) ? $monthtransaction_totals['total_sell_return_inc_tax'] : 0;
            $monthoutput['total_sell']          = $monthtotal_sell_inc_tax - $monthtotal_sell_return_inc_tax;
            $monthoutput['invoice_due']         = $monthsell_details['invoice_due'];
            // *********** Annualy Sale            ************ \\
            // *********** Annualy Purchase        ************ \\
            // *********** Annualy Debit Sale      ************ \\
            // *********** Annualy Debit Purchase  ************ \\
            $yearsell_details       = $this->transactionUtil->getSellTotals($business_id, $yearstart, $yearend, $location_id, $user->id,$reportSetting,1);
            $yearpurchase_details   = $this->transactionUtil->getPurchaseTotals($business_id, $yearstart, $yearend, $location_id, $user->id,$reportSetting,1);
            $yeartransaction_totals = $this->transactionUtil->getTransactionTotals(
                $business_id,
                $transaction_types,
                $yearstart,
                $yearend,
                $location_id, $user->id,$reportSetting,1
            );
            $yeartotal_purchase_inc_tax        = !empty($yearpurchase_details['total_purchase_inc_tax']) ? $yearpurchase_details['total_purchase_inc_tax'] : 0;
            $yeartotal_purchase_return_inc_tax = $yeartransaction_totals['total_purchase_return_inc_tax'];
            $yeartotal_purchase                = $yeartotal_purchase_inc_tax - $yeartotal_purchase_return_inc_tax;
            $yearoutput                        = $yearpurchase_details;
            $yearoutput['total_purchase']      = $yeartotal_purchase;
            $yeartotal_sell_inc_tax            = !empty($yearsell_details['total_sell_inc_tax']) ? $yearsell_details['total_sell_inc_tax'] : 0;
            $yeartotal_sell_return_inc_tax     = !empty($yeartransaction_totals['total_sell_return_inc_tax']) ? $yeartransaction_totals['total_sell_return_inc_tax'] : 0;
            $yearoutput['total_sell']          = $yeartotal_sell_inc_tax - $yeartotal_sell_return_inc_tax;
            $yearoutput['invoice_due']         = $yearsell_details['invoice_due'];
            

            // *********** Daily   Expense  ************ \\
            $dailyexpenses      = $this->transactionUtil->getTotalByType("expense",$reportSetting,$dailystart,$dailyend);
            $dailytotal_expense = ($dailyexpenses["total"]["total_amounts"] != null )?$dailyexpenses["total"]["total_amounts"]:0;
            // *********** Monthly Expense  ************ \\ 
            $monthexpenses      = $this->transactionUtil->getTotalByType("expense",$reportSetting,$monthstart,$monthend);
            $monthtotal_expense = ($monthexpenses["total"]["total_amounts"] != null )?$monthexpenses["total"]["total_amounts"]:0;
            // *********** Annualy Expense  ************ \\ 
            $yearexpenses       = $this->transactionUtil->getTotalByType("expense",$reportSetting,$yearstart,$yearend);
            $yeartotal_expense  = ($yearexpenses["total"]["total_amounts"] != null )?$yearexpenses["total"]["total_amounts"]:0;
           
            $report = [
                    // *** 1  *** \\ 
                    "DailySale"             => $dailyoutput['total_sell'],
                    "MonthlySale"           => $monthoutput['total_sell'],
                    "AnnualySale"           => $yearoutput['total_sell'],
                    // *** 2  *** \\ 
                    "DailyDebitSale"        => $dailyoutput['invoice_due'],
                    "MonthlyDebitSale"      => $monthoutput['invoice_due'],
                    "AnnualyDebitSale"      => $yearoutput['invoice_due'],
                    // *** 3  *** \\ 
                    "DailyPurchase"         => $dailyoutput['total_purchase'],
                    "MonthlyPurchase"       => $monthoutput['total_purchase'],
                    "AnnualyPurchase"       => $yearoutput['total_purchase'],
                    // *** 4  *** \\ 
                    "DailyDebitPurchase"    => $dailyoutput['purchase_due'],
                    "MonthlyDebitPurchase"  => $monthoutput['purchase_due'],
                    "AnnualyDebitPurchase"  => $yearoutput['purchase_due'],
                    // *** 5  *** \\ 
                    "DailyExpense"          => $dailytotal_expense ,
                    "MonthlyExpense"        => $monthtotal_expense ,
                    "AnnualyExpense"        => $yeartotal_expense  ,
                ];
            //  .......  
            $closing           = \App\Product::closing_stock($business_id);
            
            // *** Daily Profit
            $Dailydata           = $this->transactionUtil->getProfitLossDetails($business_id, $location_id, $dailystart, $dailyend,$user->id,$reportSetting,1);
            $Dailynet_sales      = $Dailydata['total_sell']     +   $Dailydata['total_sell_shipping_charge']     -  $Dailydata['total_sell_return']      -  $Dailydata['total_sell_discount'];
            $Dailynet_purchase   = $Dailydata['total_purchase'] +   $Dailydata['total_purchase_shipping_charge'] -  $Dailydata['total_purchase_return']  -  $Dailydata['total_purchase_discount'] -  $closing ;
            $Dailycross_profit   = $Dailynet_sales    - $Dailynet_purchase;
            $Dailynet_profit     = $Dailycross_profit - $Dailydata['total_expense'] + $Dailydata['total_reveneus'];
           
            // *** Monthly Profit
            $Monthlydata         = $this->transactionUtil->getProfitLossDetails($business_id, $location_id, $monthstart, $monthend,$user->id,$reportSetting,1);
            $Monthlynet_sales    = $Monthlydata['total_sell']     +   $Monthlydata['total_sell_shipping_charge']     -  $Monthlydata['total_sell_return']      -  $Monthlydata['total_sell_discount'];
            $Monthlynet_purchase = $Monthlydata['total_purchase'] +   $Monthlydata['total_purchase_shipping_charge'] -  $Monthlydata['total_purchase_return']  -  $Monthlydata['total_purchase_discount'] -  $closing ;
            $Monthlycross_profit = $Monthlynet_sales    - $Monthlynet_purchase;
            $Monthlynet_profit   = $Monthlycross_profit - $Monthlydata['total_expense'] + $Monthlydata['total_reveneus'];
            
            // *** Annualy Profit
            $Annualydata         = $this->transactionUtil->getProfitLossDetails($business_id, $location_id, $yearstart, $yearend,$user->id,$reportSetting,1);
            $Annualynet_sales    = $Annualydata['total_sell']     +   $Annualydata['total_sell_shipping_charge']     -  $Annualydata['total_sell_return']      -  $Annualydata['total_sell_discount'];
            $Annualynet_purchase = $Annualydata['total_purchase'] +   $Annualydata['total_purchase_shipping_charge'] -  $Annualydata['total_purchase_return']  -  $Annualydata['total_purchase_discount'] -  $closing ;
            $Annualycross_profit = $Annualynet_sales    - $Annualynet_purchase;
            $Annualynet_profit   = $Annualycross_profit - $Annualydata['total_expense'] + $Annualydata['total_reveneus'];
            
            $array = [
                        "DailyProfit"   => $Dailynet_profit,
                        "MonthlyProfit" => $Monthlynet_profit,
                        "AnnualyProfit" => $Annualynet_profit,
                     ];    
            $currency = \App\Models\ExchangeRate::where("business_id",$business_id)->where("source",1)->first();
            $symbol   =  \App\Currency::find($currency->currency_id);
                     
            return response()->json([
                        "Status"   => 200,
                        "Message"  => " Successfully Access ",
                        "Report"   => $report, 
                        "Currency" => ($symbol)?$symbol->currency . " - " .$symbol->symbol:"", 
                        "Profit"   => $array, 
                        "Token"    => $token,
                    ]);
        }catch(Exception $e){
            DB::rollBack();
            \Log::emergency("File" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            \Log::alert($e);
            return response()->json([
                "status"   => 403,
                "message"  => " Failed ",
                "token"    => $token, 
            ]);
        }

    }



     
    
    
}
