<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <title>@lang("home.Gournal Voucher")</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style type="text/css">

        body{

            background-color: #f7f7f7;

        }

        .bill{

            min-height: 200px;

            background-color: #f7f7f7;

            margin: 0 auto;

            font-size: 12px;
 
        }
 
        .bord{
             border: .5px solid #8e0f82;
            padding: 10px;
            
         }
        .bords{
            text-align: left
            
         }
        .title_voucher{
            border: 0px solid black;
            text-align: center;
            border-radius: 10px;
            font-size: x-large;
            padding: 10px;
        }
        .date_voucher{
            border: 0px solid black;
            text-align: right;
            border-radius: 10px;
            font-size: larger;
            padding: 10px;
        }
        .references {
            font-size: medium;
       }
       .bodies{
            border: 0px solid black;
            width:100%;
            border-radius:.2rem;
        }
       .tab{
            width:100%;
         }
        tr {
            border-bottom: 1px solid #8e0f82 !important;
        }
       .head{
            background-color: #8e0f82;
            color:#f7f7f7;
            border: 1px solid #8e0f82;
        }
        
        td{
            border: 0px solid #8e0f82;
            text-align: center;
            box-shadow: 2px 2px 1px black;
            padding:0px;
            line-height: 30px;
        }
        tbody th{
            color:  #000000;
            font-weight: 700;
            border-top:1px solid #727272;
            border-bottom:0px solid #727272;
            
        }
        tfoot th{
      
            color:  #000000;
            font-weight: 700;
            border-top:1px solid #727272;
            border-bottom:0px solid #727272;
            
        }
        th{
            color:  #ffffff;
            border-bottom:1px solid #8e0f82;

            
        }
         

    </style>

</head>

<body>

    <div class="bill"  >
        <table   style="width: 100%;margin-bottom:5px;  padding-bottom:25px">
            <tbody>
                <tr >
                    <td   style="border:0px solid grey;  border-radius: 5px 10px 15px 20px;">
                        <img src="http://order-uae.com/assets/dana.jpeg"   style=" padding:10px;max-width: 300px;height:350px;border-bottom:2px solid #8e0f82;border-radius:10px">
                    </td>
                    <td style="text-align: right; width:400px;padding:10px;
                            line-height:13px;font-size:12px;border-right:1px solid grey;
                        "> @if($layout) {!! $layout->header_text !!} @endif</td>
                </tr>
            </tbody>
        </table>
     
         
        <div class="title_voucher">
            <b> @lang("home.Gournal Voucher")</b>   
        </div>
        <div>&nbsp;</div>

        <div style="position:relative;border:0px solid black;width:100%">
            <b>JV/No. &nbsp; : </b><span > {{$invoice->ref_no}}</span> . {{" / "}} . {{($entry)?$entry->refe_no_e:""}}  <br>
            <b>JV/Date. &nbsp; : </b><span >{{$invoice->date }}</span> <br>       
            {{-- <b>DHS//FC Rate &nbsp; : </b><span > </span>         --}}
         </div>
        <div style="position:relative;border:0px solid black;margin-top:-40px;width:100%">
            <div style="border:0px solid black; width:40%;margin-left:80%;">
                <b>User  &nbsp;: </b><span > {{$user}}</span>  <br>
                <b>Date. &nbsp; : </b><span >{{$invoice->created_at->format("Y-m-d")}}</span> <br>
                <b>Page No. &nbsp; : </b><span >{{1}} . OF . {{$pages}}</span>        
            </div>
        </div>
                  
                    
                
         
       
         
        <div>
            &nbsp;
        </div>
        @php   $payment = \App\TransactionPayment::where("payment_voucher_id",$invoice->id)->first(); @endphp
        @php  if(!empty($payment))  { $trans  = \App\Transaction::where("id",$payment->transaction_id)->first(); }   @endphp
        <div class="bodies">
            <table class="tab">
                <thead >
                    <tr class="head">
                        <th>  Code  </th>

                        <th>  Account Name  </th>
                   
                        <th>  Note  </th>

                        <th>  Debit  </th>
                     
                        <th>  Credit  </th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $total_debit   =  0;
                        $total_credit  =  0;
                    @endphp
                    @foreach($items as $it)
                    @php
                        $credit_ac     = \App\Account::where("id",$it->credit_account_id)->first();
                        $debit_ac_tax  = \App\Account::where("id",$it->tax_account_id)->first();
                        $debit_ac      = \App\Account::where("id",$it->debit_account_id)->first();
                        $total_debit  += (!empty($debit_ac))?($it->amount-$it->tax_amount):0;
                        $total_debit  += (!empty($debit_ac_tax))?($it->tax_amount):0;
                        $total_credit += (!empty($credit_ac))?($it->amount):0;
                    @endphp
                    @if(!empty($credit_ac))
                        <tr>
                            <th>{{$credit_ac->account_number}}</th>
                            <th>{{$credit_ac->name}}</th>
                            <th>{{$it->text}}</th>
                            <th></th>
                            <th>{{$it->amount}}</th>
                        </tr>
                         
                    @endif
                    @if(!empty($debit_ac))
                        <tr>
                            <th>{{$debit_ac_tax->account_number}}</th>
                            <th>{{$debit_ac_tax->name}}</th>
                            <th>{{$it->text}}</th>
                            <th>{{$it->tax_amount}}</th>
                            <th> </th>
                        </tr>
                    @endif
                    
                    @if(!empty($debit_ac))
                        <tr>
                            <th>{{$debit_ac->account_number}}</th>
                            <th>{{$debit_ac->name}}</th>
                            <th>{{$it->text}}</th>
                            <th>{{$it->amount - $it->tax_amount}}</th>
                            <th> </th>
                        </tr>
                         
                    @endif
                        
                @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <th style="background-color:rgb(199, 199, 199); border:1px solid rgb(199, 199, 199)"> </th>
                        <th style="background-color:rgb(199, 199, 199); border:1px solid rgb(199, 199, 199)"> </th>
                        <th style="background-color:rgb(199, 199, 199); border:1px solid rgb(199, 199, 199)"> Total   </th>
                        <th style="background-color:rgb(199, 199, 199); border:1px solid rgb(199, 199, 199)"> {{$total_debit}}</th>
                        <th style="background-color:rgb(199, 199, 199); border:1px solid rgb(199, 199, 199)"> {{$total_credit}}</th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div>&nbsp;</div>
        <div>&nbsp;</div>
    
        <div style="font-size: 12px; text-align:left">
            <b>  Prepared By :</b>   <br>
        </div>
        <div style="font-size: 12px; margin-top:-15px;">
            <div style="width:50%;margin-left:70%;text-align:left">
                <b>  Approved By :</b>   <br>
            </div>
        </div>
                     
   
                    
             
            {{-- <div class="row   date_voucher " style="text-align: right">
                <b>Final Balance : </b>
                @php
                $account = \App\Account::where("contact_id",$invoice->contact->id)->first();
                $Atr     = \App\AccountTransaction::where("account_id",$account->id)->select("amount");
                $pr_amount  =  \App\AccountTransaction::whereHas('transaction',function($query) use( $invoice){
                                                $query->where('contact_id',$invoice->contact->id);
                                                $query->whereIn('type',['purchase','purchase_return']);
                                        })->whereHas('account',function($query) use( $invoice){
                                                $query->where('contact_id',$invoice->contact->id);
                                        })->where('type','credit')->where("note","!=","refund Collect")
                                        ->sum("amount");
                $pr_payed   =  \App\AccountTransaction::whereHas('account',function($query) use( $invoice){
                                                    $query->where('contact_id',$invoice->contact->id);
                                                })
                                                ->where('type','debit')
                                                ->whereNull("for_repeat")
                                                ->whereNull("id_delete")
                                                ->sum('amount');
                
                
                $diff       =   $pr_payed - $pr_amount;
                if($diff < 0 ){
                    $price= ($diff*-1)  ;
                    $type= " / Credit"  ;
                }else{
                    $price= ($diff)  ;
                    $type= " / Debit"  ;
                }
                @endphp
                <span >@format_currency($price)  {{$type}}</span>
            </div> --}}
            

       

    <!--  -->
 
        
      
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>